//#-editable-code
import UIKit
import PlaygroundSupport

class TextViewController : UIViewController {
    
    override func loadView() {
        
        let textView = UITextView()
        textView.text = "Hello World!\nHello Playground!"
        
        self.view = textView
    }
    
}

PlaygroundPage.current.liveView = TextViewController()
//#-end-editable-code


/*:
 For more information, see [The Swift Programming Language.](http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/)
 */


//: [Next Topic](@next)
