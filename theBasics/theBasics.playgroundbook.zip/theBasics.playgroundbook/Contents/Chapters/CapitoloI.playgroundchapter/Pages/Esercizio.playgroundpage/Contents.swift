//#-hidden-code
import Foundation
//#-end-hidden-code
//: # ESERCIZIO N.1
/*:
 **Obiettivo:**
 Si scriva un programma capace di compiere le 4 operazioni (`somma`, `sottrazione`, `moltiplicazione` e `divisione`) tra due numeri reali inseriti da tastiera.
 
 Dopo che sono stati inseriti i due numeri, detti **A** e **B**, il programma dovrà visualizzare i quattro valori `A+B`, `A-B`, `A*B`, `A/B`.
 */
/*:
 - Note:
 *Si ipotizzi che sia B ≠ 0*
 */
//#-editable-code Tocca per inserire il codice

//#-end-editable-code
