//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code

/*:
 CHALLENGE N.1
 Si scriva un programma in linguaggio C che legga un valore intero
 e visualizzi il valore intero precedente e il successivo.

 */

var num: Int  /* numero inserito */
var prec: Int
var succ: Int  /* numero precedente e numero successivo */

/* LEGGI IL NUMERO */
show("Immetti il numero: ")
num = askForNumber()

/* CALCOLA IL NUMERO PRECEDENTE */
prec = num - 1 ;
/* CALCOLA IL NUMERO SUCCESSIVO */
succ = num  + 1 ;
/* STAMPA IL RISULTATO */

show("Il numero inserito é: " + String(num))
show("Il numero precedente a \(num) é: \(prec)")
show("Il numero successivo a "  + String(num) + " é: " + String(succ))

//#-end-editable-code


//: [Next Topic](@next)
