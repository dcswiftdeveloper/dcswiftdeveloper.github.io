//: # Condividi un Post
//: **Sfida:** prova a creare e a condividere un post seguendo le indicazioni di seguito fornite.
//:
//: * Callout(⚠️ Nota Bene ⚠️):
//: Anche se non visibile nel codice di seguido riportato, la `struct` Post è disponibile e può essere utilizzata nell'implementazione richiesta.
//:
//: - Note:
//:    1. Crea un post con un testo descrittivo, un'immagine, un luogo di pubblicazione e un hashtag
//:    2. Crea la funzione `sendPost(_ post: Post)`, che avrà il compito di condividere un post tramite mail
//:    3. Puoi includere tra i destinatari anche la nostra mail di supporto: playgrounds@sacrocuorenapoli.it
//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
print("** Service Console **\n\n")
/// Modello del Post
struct Post: Hashable, Codable {
    /// Testo del Post (Type: String)
    var description: String

    /// Numero di like del Post (Type: Int)
    var likeCounter = 0

    /// Numero di commenti del Post (Type: Int)
    var commentCounter: Int { comments.count }

    /// Immagine del Post (Type: Data?)
    var image: Data?

    /// Commenti del Post (Type: [String: String])
    var comments: [String: String] = [:]

    /// Tag del Post (Type: [String: Int])
    var displayTags: [String: Int] = [:]

    /// Tag del Post (Type: [String])
    var tags: [String] = []

    /// Hashtag del Post (Type: [String: Int])
    var displayHashtags: [String: Int] = [:]

    /// Hashtag del Post (Type: [String])
    var hashtags: [String] = []

    /// Numero di condivisioni del Post (Type: Int)
    var shareCounter = 0

    let date = Date()

    /// Data di pubblicazione del Post formattata (Type: String)
    var publicationDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium

        return formatter.string(from: date)
    }

    /// Luogo del Post (Type: String?)
    var publicationPlace: String?

    /// Array delle Proprietà utilizzate dal Post (Type: [Property])
    var properties: [Property] = []

    /// Incrementa il numero di like del Post
    mutating func like() {
        likeCounter += 1
    }

    /// Aggiunge un commento al Post richiedendo un username e il testo del commento
    mutating func comment(_ username: String, text: String) {
        comments[username] = text
    }

    /// Incrementa il numero di condivisioni di un Post
    mutating func share() {
        shareCounter += 1
    }

    /// Proprietà di un Post
    enum Property: String, Codable {
        case description = "Testo ✍️"
        case image = "Foto 🖼"
        case tags = "Tags ＠"
        case hashtags = "Hashtags #️⃣"
        case publicationPlace = "Luogo 📍"
    }

    init(withDescription description: String) {
        self.description = description
        properties.append(.description)
    }
}
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
