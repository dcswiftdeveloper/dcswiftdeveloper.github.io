//: # Prova anche Tu!
//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code

import Foundation
print("** Service Console **\n\n")

//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
