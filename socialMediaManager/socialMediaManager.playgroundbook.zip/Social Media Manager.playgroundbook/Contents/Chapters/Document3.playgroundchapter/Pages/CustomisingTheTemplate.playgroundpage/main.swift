//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
//#-end-hidden-code
//: # Modifica il Template
//: **Presentazione:** di seguito sono illustrati i passaggi necessari per personalizzare il modello `Risposte`, con riferimento al metodo `sharePost()` introdotto per gestire la condivisione di un post tramite email.
//:
//: - Important: È necessario il supporto dell'app Xcode (⚠️ disponibile solo su Mac ⚠️)
//#-hidden-code
//#-end-hidden-code
//: - Note:
//:     - La procedura, con i dovuti adattamenti, può essere replicata qualora l'utente intendesse introdurre una nuova funzionalità nel modello di Playground utilizzato.
//:     - Tutte le modifiche apportate sono rintracciabili all'interno del progetto Xcode, digitando `// MARK:- Mail Sharing #CustomMethod` nel *Find Navigator*
//:
//:  * Callout(Step 1):
//:     Importare le librerie necessarie (Rif.: `AnswersViewController.swift`)
import SafariServices
import MessageUI
//:  * Callout(Step 2):
//:     Adottare gli eventuali protocolli rendendo la classe ad essi conforme (Rif.: `AnswersViewController.swift`)
class AnswersViewController: UITableViewController, MFMailComposeViewControllerDelegate
//#-hidden-code
{}
//#-end-hidden-code
//:  * Callout(Step 3):
//:     Aggiungere il metodo necessario all'implementazione della funzionalità desiderate (Rif.: `AnswersViewController.swift`)
func shareWithEmail(text: String)
//#-hidden-code
{}
//#-end-hidden-code
//:  * Callout(Step 4):
//:     Aggiungere all'enum `AnswersCommand` un `case` con il nome della funzionalità e la lista dei tipi dei parametri necessari (Rif.:  `AnswersCommand.swift`)
enum AnswersCommand {
    case shareWithEmail(String)
}
//:  * Callout(Step 5):
//:      Aggiungere un `case` allo `switch` su `command` nella funzione `receive(_ message: PlaygroundValue)` per creare un collegamento alle funzionalità di default del template *Risposte*. Richiamare la funzione creata nel controller con i parametri ottenuti dal `case` (Rif.: `AnswersViewController.swift`)
func receive(_ message: PlaygroundValue) {
    guard let command = AnswersCommand(message) else {
        return
    }
    
    switch command {
    case .shareWithEmail(let text):
        shareWithEmail(text: text)
    }
}
//:  * Callout(Step 6):
//:      Aggiungere un `case` per descrivere il comportamento della nuova funzionalità: nome del comando e lista dei parametri previsti (Rif.: `AnswersCommand.swift`).
extension AnswersCommand {
    fileprivate var playgroundValue: PlaygroundValue {
        switch self {
        case .shareWithEmail(let text):
        
        let dict: [String: PlaygroundValue] = [
            "Command": .string("ShareWithEmail"),
            "Text": .string(text)
        ]
        return .dictionary(dict)
        }
    }
}
//:  * Callout(Step 7):
//:      Aggiungere un `case` con il nome del comando da implementare. Prevedere un *optional binding* per ogni parametro da scambiare ed attivare il valore corrispondente dell'enumerazione `AnswersCommand` (Rif.: `AnswersCommand.swift`)
extension AnswersCommand {
    init?(_ playgroundValue: PlaygroundValue) {
        guard case let .dictionary(dict) = playgroundValue else {
            return nil
        }
        
        guard case let .string(command)? = dict["Command"] else {
            return nil
        }
        
        switch command {
        case "ShareWithEmail":
            guard case let .string(text)? = dict["Text"] else {
                return nil
            }
            self = .shareWithEmail(text)
                //#-hidden-code
        default:
            return nil
                //#-end-hidden-code
        }
    }
}
//:  * Callout(Step 8):
//:      Definire la funzione in modo da poter inviare il comando al `ViewController` (Rif.: `AnswersLiveView.swift`).
//#-hidden-code
extension PlaygroundLiveViewMessageHandler {
    func send(_ command: AnswersCommand) {
        self.send(command.playgroundValue)
    }
}
//#-end-hidden-code
class AnswersLiveViewClient: PlaygroundRemoteLiveViewProxyDelegate  {
    var responses: [String] = []
    
    init() { }
    
    func shareWithEmail(text: String) {
        guard let liveViewMessageHandler = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            return
        }
        
        liveViewMessageHandler.send(AnswersCommand.shareWithEmail(text))
    }
    //#-hidden-code
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
    }
    
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        guard let command = AnswersCommand(message) else {
            return
        }
    }
    //#-end-hidden-code
}
//:  * Callout(Step 9):
//:     Dichiarare una `public` `func` per rendere disponibile la funzionalità ovunque nel Playground (Rif.: `AnswersPlayground.swift`).
private let answersLiveViewClient = AnswersLiveViewClient()

public func sharePost(text: String) {
    answersLiveViewClient.shareWithEmail(text: text)
}
//#-hidden-code
show("🧑‍💻 > Complimenti!")
sleep(1)
show("🧑‍💻 > Se sei riuscito ad eseguire tutti i passaggi, avrai personalizzato con successo il modello \"Risposte\"!")
sleep(2)
show("🧑‍💻 > Sei bisogno di ulteriori chiarimenti usa la funzione getSupport()")
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-editable-code
// Non c'è bisogno di aggiungere altro al Playground. Basta fare un tap su "Esegui codice".
//#-end-editable-code
