public extension String {
	/// Restituisce una stringa formattata come Hashtag
    func asHashtag() -> String {
        let stringWithoutSpacing = self.replacingOccurrences(of: " ", with: "")
        return "#\(stringWithoutSpacing)"
    }
}
