//: # Pubblica il tuo Post!
//: Benvenuti in **Social Media Manager**, un playground book inspirato ai social network in "salsa" Swift, grazie al quale potrai gestire le seguenti operazioni disponibili su un post:
//:
//:  * Callout(Funzionalità):
//:     - **Creazione**: potrai aggiungere un'immagine, un testo descrittivo, taggare persone, inserire hashtag, commentare e mettere like.
//:     - **Gestione**\
//:            - `Modifica`: anche dopo la pubblicazione avrai la possibilità di modificare tutte le proprietà del tuo post.\
//:            - `Eliminazione`: potrai rimuovere il tuo post o alcune sue proprietà, come gli hashtag o i tag.
//:     - ⚠️ **Condivisione** tramite `email`: funzionalità  disponibile solo su iPad ⚠️
//:     - **Salvataggio:** niente paura! I tuoi post rimarranno al sicuro anche quando il Playground non sarà in esecuzione.
//:     - **Gestione galleria immagini:** per info [clicca qui](@next)
//:
//: - Experiment: **Azioni suggerite**\
//: Crea il tuo primo post, personalizzando tutte le proprietà disponibili. \
//: Eventualmente potrai condividerlo con i tuoi amici, lasciandoti guidare dall'assistente (🧑‍💻)
//:
//:  * Callout(Autori):
//:     - **Alessio Garzia Marotta Brusco** (Sviluppatore)
//:     - **Giovanni Michele Napoli** (Redattore)
//:     - **Paolo Scocca** (Tester)
//:     - **Giulia Lin** (Autrice immagine di copertina)
//:     - **Domenico Caggiano** (Coordinatore)
//#-hidden-code
//
//  main.swift
//
//  Copyright © 2021-2022 Istituto Sacro Cuore Napoli. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
print("** Service Console **\n\n")
//#-end-hidden-code
/// Modello del Post
struct Post: Hashable, Codable {
    /// Testo del Post (Type: String)
    var description: String
    
    /// Numero di like del Post (Type: Int)
    var likeCounter = 0
    
    /// Numero di commenti del Post (Type: Int)
    var commentCounter: Int { comments.count }
    
    /// Immagine del Post (Type: Data?)
    var image: Data?
    
    /// Commenti del Post (Type: [String: String])
    var comments: [String: String] = [:]
    
    /// Tag del Post (Type: [String: Int])
    var displayTags: [String: Int] = [:]
    
    /// Tag del Post (Type: [String])
    var tags: [String] = []
    
    /// Hashtag del Post (Type: [String: Int])
    var displayHashtags: [String: Int] = [:]
    
    /// Hashtag del Post (Type: [String])
    var hashtags: [String] = []
    
    /// Numero di condivisioni del Post (Type: Int)
    var shareCounter = 0
    
    let date = Date()
    
    /// Data di pubblicazione del Post formattata (Type: String)
    var publicationDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    /// Luogo relativo al Post (Type: String?)
    var publicationPlace: String?
    
    /// Array delle proprietà utilizzate dal Post (Type: [Property])
    var properties: [Property] = []
    
    /// Incrementa il numero di like del Post
    mutating func like() {
        likeCounter += 1
    }
    
    /// Aggiunge un commento al post richiedendo un username e il testo del commento
    mutating func comment(_ username: String, text: String) {
        comments[username] = text
    }
    
    /// Incrementa il numero di condivisioni di un Post
    mutating func share() {
        shareCounter += 1
    }
    
    /// Proprietà di un Post
    enum Property: String, Codable {
        case description = "Testo ✍️"
        case image = "Foto 🖼"
        case tags = "Tags ＠"
        case hashtags = "Hashtags #️⃣"
        case publicationPlace = "Luogo 📍"
    }
    
    init(withDescription description: String) {
        self.description = description
        properties.append(.description)
    }
}

// Variabili di stato
var numberOfTags = 0
var numberOfHashtags = 0

final class ProfileManager: Codable {
    var posts: [Post]
    var postsDisplay: [String: Int]
    var username: String
    var wantsToContinue = true
    
    /// Posizione di un Post salvato
    enum PostLocation {
        case inArray, inDictionary, everywhere
    }
    
    /// Mostra il contenuto del Post fornito in ingresso
    func showPost(_ post: Post) {
        sleep(1)
        
        show("👤: \(username)")
        
        show("📝: \(post.description)")
        
        if let pubPlace = post.publicationPlace {
            show("ℹ️: \(pubPlace) - \(post.publicationDate)")
        } else {
            show("📅: \(post.publicationDate)")
        }
        
        if let image = post.image { show(Image(data: image)!) }
        
        if !post.tags.isEmpty {
            let joinedTags = post.tags.joined(separator: " ")
            show(joinedTags)
        }
        
        if !post.hashtags.isEmpty {
            let joinedHashtags = post.hashtags.joined(separator: " ")
            show(joinedHashtags)
        }
        
        show("❤️\(post.likeCounter) – 💬\(post.commentCounter) – 📱\(post.shareCounter)")
    }
    
    /// Crea e salva un Post
    func createPost() {
        var isChoiceInvalidForTags = true
        var isChoiceInvalidForHashtags = true
        
        var post = Post(withDescription: "")
        var properties: [Post.Property] = []
        show("🧑‍💻 > Crea il tuo Post")
        sleep(1)
        
        // Aggiunge una descrizione
        show("🧑‍💻 > Digita il testo ✍️")
        post.description = ask("Testo")
        
        // Aggiunge un'immagine
        show("🧑‍💻 > Vuoi aggiungere un'immagine?")
        if askForYesOrNo() {
            show("🧑‍💻 > Scegline una dalla tua galleria 🖼")
            post.image = askForChoice(images: images).jpegData(compressionQuality: 1)!
            properties.append(.image)
        }
        
        // Aggiunge una posizione
        show("🧑‍💻 > Vuoi aggiungere una posizione 📍? ")
        if askForYesOrNo() {
            show("🧑‍💻 > Digita la Posizione")
            post.publicationPlace = ask("Posizione")
            properties.append(.publicationPlace)
        }
        
        // Aggiunge tag
        show("🧑‍💻 > Vuoi taggare delle persone? ＠")
        if askForYesOrNo() {
            show("🧑‍💻 > Quante persone vuoi taggare?")
            
            while isChoiceInvalidForTags {
                numberOfTags = askForNumber("Numero di Tag")
                if !(numberOfTags <= 0) {
                    isChoiceInvalidForTags = false
                } else {
                    show("🧑‍💻 > ⚠️ Inserire un numero maggiore di 0 ⚠️")
                }
            }
            
            for i in 1...numberOfTags {
                let tag = ask("Tag #\(i)").asTag()
                post.tags.append(tag)
                post.displayTags[tag] = post.displayTags.isEmpty ? 0 : post.displayTags.count - 1
            }
            properties.append(.tags)
        }
        
        // Aggiunge hashtag
        show("🧑‍💻 > Vuoi aggiungere degli Hashtag? #️⃣")
        if askForYesOrNo() {
            show("🧑‍💻 > Quanti hashtag vuoi aggiungere?")
            
            while isChoiceInvalidForHashtags {
                numberOfHashtags = askForNumber("Numero di Hashtag")
                print(post.displayHashtags)
                if !(numberOfHashtags <= 0) {
                    isChoiceInvalidForHashtags = false
                } else {
                    show("🧑‍💻 > ⚠️ Inserire un numero maggiore di 0 ⚠️")
                }
            }
            
            for i in 1...numberOfHashtags {
                let hashtag = ask("Hashtag #\(i)").asHashtag()
                post.hashtags.append(hashtag)
                post.displayHashtags[hashtag] = post.displayHashtags.isEmpty ? 0 : post.displayHashtags.count - 1
            }
            properties.append(.hashtags)
        }
        
        post.properties.append(contentsOf: properties)
        
        // Mostra esito
        show("🧑‍💻 > Post Creato! ✅")
        sleep(1)
        
        // Mostra il post creato
        showPost(post)
        
        // Salva il post
        savePost(post)
    }
    
    /// Presenta la schermata di condivisione di un Post tramite email
    func sendPost(at index: Int) {
        posts[index].share()
        
        let tags = posts[index].tags.joined(separator: " ")
        let hashtags = posts[index].hashtags.joined(separator: " ")
        
        sharePost(
            description: "✍️: \(posts[index].description)",
            likeCounter: posts[index].likeCounter,
            commentCounter: posts[index].commentCounter,
            image: posts[index].image ?? Data(),
            tag: tags,
            hashtag: hashtags,
            shareCounter: posts[index].shareCounter,
            publicationDate: posts[index].publicationDate,
            publicationPlace: posts[index].publicationPlace ?? "n/a"
        )
        
        pauseUntilTapped(message: "Operazione Conclusa")
    }
    
    /// Salva il Post fornito in ingresso
    func savePost(_ post: Post) {
        if posts.contains(post) == false {
                    posts.append(post)
                }
                let key = "\(post.description) - \(post.publicationDate)"
                let value = posts.isEmpty ? 0 : posts.count - 1

                let containsValue: ((key: String, value: Int)) -> Bool = { $0.value == value }

                if postsDisplay.contains(where: containsValue) == false {
                    postsDisplay[key] = value
                }
                save()
    }
    
    /// Modifica le proprietà di un Post selezionate dall'utente
    func modifyPost(at index: Int) {
        func modifyDescription() {
            show("🧑‍💻 > Inserisci la nuova descrizione 🖋")
            posts[index].description = ask("Descrizione")
        }
        
        func modifyImage() {
            show("🧑‍💻 > Scegli una nuova immagine 🖼")
            posts[index].image = askForChoice(images: images).jpegData(compressionQuality: 1)
        }
        
        func modifyHashtags() {
            show("🧑‍💻 > Vuoi aggiungere o rimuovere un hashtag? #️⃣")
            if askForChoice(strings: ["Aggiungere ✍️", "Rimuovere 🗑"]) == "Aggiungere ✍️" {
                show("🧑‍💻 > Aggiungi l'hashtag")
                posts[index].hashtags.append(ask("Hashtag").asHashtag())
                
            } else {
                show("🧑‍💻 > Scegli l'hashtag che vuoi eliminare 🗑")
                var hashtagsDisplayKeys: [String] = posts[index].displayHashtags.keys.map {
                    $0
                }
                let hashtagIndex = posts[index].displayHashtags[askForChoice(strings: hashtagsDisplayKeys)] as! Int
                
                posts[index].hashtags.remove(at: hashtagIndex)
            }
        }
        
        func modifyTags() {
            show("🧑‍💻 > Vuoi aggiungere o rimuovere un tag? ＠")
            if askForChoice(strings: ["Aggiungere ✍️", "Rimuovere 🗑"]) == "Aggiungere ✍️" {
                show("🧑‍💻 > Aggiungi il tag")
                posts[index].tags.append(ask("Tag").asTag())
                
            } else {
                show("🧑‍💻 > Scegli il tag che vuoi eliminare 🗑")
                var tagsDisplayKeys: [String] = posts[index].displayTags.keys.map {
                    $0
                }
                let tagIndex = posts[index].displayTags[askForChoice(strings: tagsDisplayKeys)] as!
                    Int
                
                posts[index].tags.remove(at: tagIndex)
            }
        }
        
        func modifyPublicationPlace() {
            show("🧑‍💻 > Inserisci il nuovo luogo 📍")
            posts[index].publicationPlace = ask("Luogo")
        }
        
        
        show("🧑‍💻 > Ecco il post che hai scelto")
        showPost(posts[index])
        
        show("🧑‍💻 > Cosa vuoi modificare del tuo post? 🔎")
        let properties = posts[index].properties.map { $0.rawValue }
        let options = properties + ["❌ Annulla ❌"]
        
        switch askForChoice(strings: options) {
        case Post.Property.description.rawValue:
            modifyDescription()
            
        case Post.Property.image.rawValue:
            modifyImage()
            
        case Post.Property.hashtags.rawValue:
            modifyHashtags()
            
        case Post.Property.tags.rawValue:
            modifyTags()
            
        case Post.Property.publicationPlace.rawValue:
            modifyPublicationPlace()

        case "❌ Annulla ❌":
            show("🧑‍💻 > Azione annullata")
            return

        default:
            show("An error occured modifing this post: \(posts[index])")
            break
        }

        save()
        show("🧑‍💻 > Modifiche apportate correttamente ✅")
        showPost(posts[index])
    }
    
    /// Cancella un determinato Post attraverso la posizione fornita
    func deletePost(_ post: Post, _ location: PostLocation) throws {
        switch location {
        case .inArray:
            guard let index = postsDisplay["\(post.description) - \(post.publicationDate)"] else {
                throw PostError.invalidIndexForPost
                return
            }
            posts.remove(at: index)
            
        case .inDictionary:
            postsDisplay.removeValue(forKey: "\(post.description) - \(post.publicationDate)")
            print(postsDisplay)
            
        case .everywhere:
            do {
                try deletePost(post, .inArray)
                try deletePost(post, .inDictionary)
            } catch {
                throw error
            }
        }
        save()
    }
    
    /// Fornisce l'indice del Post selezionato
    func choosePost() -> Int {
        var postsDisplayKeys: [String] = postsDisplay.keys.map {
            $0
        }
        
        show("🧑‍💻 > Scegli un post 🔎")
        let postIndex = postsDisplay[askForChoice(strings: postsDisplayKeys)] as! Int
        
        return postIndex
    }
    
    /// Salva un istanza della Classe ProfileManager in un file JSON
    private func save() {
        do {
            let encoded = try JSONEncoder().encode(myProfileManager)
            print("Encoding succeded")

            do {
                try encoded.write(to: archiveURL)
            } catch {
                print("Error writing to the given URL: \(error.localizedDescription)")
            }
        } catch {
            print("An error was thrown while encoding: \(error.localizedDescription)")
        }
    }
    
    /// Mostra i commenti di un Post
    func showComments(forPostAt index: Int) {
        let post = posts[index]
        guard !post.comments.isEmpty else {
            show("⚠️ Non sono presenti dei commenti ⚠️")
            return
        }
        
        show("Ecco i commenti:")
        
        let formattedComments = post.comments.map { "\($0.key) \($0.value)" }
        
        formattedComments.forEach(show)
    }
    
    
    /// Mostra le reazioni ad un Post
    func reactToPost(at index: Int) {
        show("🧑‍💻 > Vuoi commentare, condividere o mettere un like a questo post? 📱")
        
        let options = ["💬 Commentare 💬", !isMacOS ? "📱 Condividere 📱" : "⚠️ Condivisione solo su iPad ⚠️", "👍 Mettere un like 👍", "❌ Annulla ❌"]
        switch askForChoice(strings: options) {
        case "💬 Commentare 💬":
            show("🧑‍💻 > Ecco i commenti presenti nel post 💬")
                        showComments(forPostAt: index)
                        show("🧑‍💻 > Scrivi il tuo commento 💬")
                        let formatter = DateFormatter()
                        formatter.dateFormat = "HH:mm:ss"
                        let dateString = formatter.string(from: Date())
                        posts[index].comments["\(username) – \(dateString)"] = ask("Commento")
        
        case "📱 Condividere 📱":
            sendPost(at: index)
        
        case "👍 Mettere un like 👍":
            pauseUntilTapped(message: "Metti Like")
            posts[index].like()
            
        case "❌ Annulla ❌":
            return
        
        case "⚠️ Condivisione solo su iPad ⚠️":
            show("🧑‍💻 > La condivisione tramite mail funziona solo su iPad.")
            
        default:
            break
        }

        savePost(posts[index])
    }
    
    init() {
        // Decodifica del file JSON per inizializzare la Classe.
        if let data = try? Data(contentsOf: archiveURL) {
            print(data)
            do {
                let decoded = try JSONDecoder().decode(ProfileManager.self, from: data)
                self.posts = decoded.posts
                self.postsDisplay = decoded.postsDisplay
                
                print("Data Loaded")
                print(decoded.posts)
                
                self.username = {
                    show("🧑‍💻 > Ciao \(decoded.username)!")
                    sleep(1)
                    show("🧑‍💻 > Sto caricando il tuo profilo")
                    sleep(1)
                    show("🧑‍💻 > ...")
                    return decoded.username
                }()
                
                return
            } catch {
                print("An error was thrown while decoding: \(error.localizedDescription)")
            }
        }
        print("No saved Data")
        self.posts = []
        self.postsDisplay = [:]
        self.username = {
            show("🧑‍💻 > Ciao!")
            sleep(1)
            show("🧑‍💻 > Sto caricando il tuo profilo")
            sleep(1)
            show("🧑‍💻 > ...")
            sleep(2)
            show("🧑‍💻 > Inserisci il tuo username")
            let username = ask("username")
            
            return username
        }()
    }
    
    /// Restituisce un valore di tipo Bool in seguito ad una scelta dell'utente
    private func askForYesOrNo() -> Bool {
        askForChoice(strings: ["✅", "❌"]) == "✅"
    }
    
    /// Esegue la Social Media App
    func run() {
        while wantsToContinue {
            show("🧑‍💻 > Cosa vuoi fare? 🔎")
            let options = ["🧑‍🎨 Creare un Post 🧑‍🎨", "🖥 Visualizzare un Post 🖥", "✍️ Modificare un Post ✍️", "🗑 Eliminare un Post 🗑", !isMacOS ? "🌎 Condividere un Post 🌎" : "⚠️ Condivisione solo su iPad ⚠️", "❌ Esci ❌"]
            
            switch askForChoice(strings: options) {
            case "🧑‍🎨 Creare un Post 🧑‍🎨":
                sleep(1)
                createPost()
                
            case "🖥 Visualizzare un Post 🖥":
                if posts.isEmpty  {
                    show("🧑‍💻 > ⚠️ Non ci sono post salvati, ne vuoi creare uno? ⚠️")
                    if askForYesOrNo() {
                        createPost()
                    } else {
                        sleep(1)
                        show("🧑‍💻 > Vuoi continuare?")
                        if !askForYesOrNo() {
                            show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                            wantsToContinue = false
                            return
                        } else {
                            continue
                        }
                    }
                }
                
                let index = choosePost()
                
                showPost(posts[index])
                sleep(1)
                show("🧑‍💻 > Vuoi vedere i commenti?")
                if askForYesOrNo() {
                    showComments(forPostAt: index)
                }
                
                reactToPost(at: index)
                
            case "✍️ Modificare un Post ✍️":
                if posts.isEmpty  {
                    show("🧑‍💻 > ⚠️ Non ci sono post salvati, ne vuoi creare uno? ⚠️")
                    if askForYesOrNo() {
                        createPost()
                    } else {
                        sleep(1)
                        show("🧑‍💻 > Vuoi continuare?")
                        if !askForYesOrNo() {
                            show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                            wantsToContinue = false
                            return
                        } else {
                            continue
                        }
                    }
                }
                
                let index = choosePost()
                modifyPost(at: index)
                
            case "🗑 Eliminare un Post 🗑":
                if posts.isEmpty  {
                    show("🧑‍💻 > ⚠️ Non ci sono post salvati, ne vuoi creare uno? ⚠️")
                    if askForYesOrNo() {
                        createPost()
                        sleep(1)
                        show("🧑‍💻 > Vuoi continuare?")
                        if !askForYesOrNo() {
                            show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                            wantsToContinue = false
                            return
                        } else {
                            continue
                        }
                    } else {
                        sleep(1)
                        show("🧑‍💻 > Vuoi continuare?")
                        if !askForYesOrNo() {
                            show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                            wantsToContinue = false
                            return
                        } else {
                            continue
                        }
                    }
                }
                
                let index = choosePost()
                print(index)
                
                show("🧑‍💻 > ⚠️ Sei sicuro di voler eliminare il post? ⚠️")
                if !askForYesOrNo() {
                    show("🧑‍💻 > Azione annullata")
                    sleep(1)
                    
                    show("🧑‍💻 > Vuoi continuare?")
                    if !askForYesOrNo() {
                        show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                        wantsToContinue = false
                        return
                    }
                }  else {
                    do {
                        try deletePost(posts[index], .everywhere)
                    } catch {
                        show(error.localizedDescription)
                        print(index)
                    }

                    show("🧑‍💻 > Post Eliminato ✅")
                    continue
                }
                
            case "🌎 Condividere un Post 🌎":
                if posts.isEmpty  {
                    show("🧑‍💻 > ⚠️ Non ci sono post salvati, ne vuoi creare uno? ⚠️")
                    if askForYesOrNo() {
                        createPost()
                    } else {
                        sleep(1)
                        show("🧑‍💻 > Vuoi continuare?")
                        if !askForYesOrNo() {
                            show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                            wantsToContinue = false
                            return
                        } else {
                            continue
                        }
                    }
                }
                
                let index = choosePost()
                sendPost(at: index)
                
            case "❌ Annulla ❌":
                show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                wantsToContinue = false
                return
                
            case "⚠️ Condivisione solo su iPad ⚠️":
                show("🧑‍💻 > La condivisione tramite mail è disponibile solo su iPad.")
                sleep(1)
                show("🧑‍💻 > Vuoi continuare?")
                if !askForYesOrNo() {
                    show("🧑‍💻 > Grazie‼️ Arrivedercii 👋")
                    wantsToContinue = false
                    return
                } else {
                    continue
                }
                
            default:
                break
            }
            sleep(1)
            show("🧑‍💻 > Vuoi continuare?")
            if !askForYesOrNo() {
                show("🧑‍💻 > Grazie‼️ Arrivederci 👋")
                wantsToContinue = false
            } else {
                continue
            }
        }
    }
}

// Crea un'istanza di ProfileManager
let myProfileManager = ProfileManager()
myProfileManager.run()
//#-editable-code Tap to enter code
// Non c'è bisogno di aggiungere altro al Playground. Basta fare un tap su "Esegui codice".
//#-end-editable-code
