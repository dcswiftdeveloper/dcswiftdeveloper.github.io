//: # Salvataggio dei Dati
//: **Sfida:** prova a creare e a salvare un post, utilizzando le funzionalità fornite dalla classe `ProfileManager`.
//:
//: * Callout(⚠️ Nota Bene ⚠️):
//: Anche se non visibili nel codice di seguito riportato, saranno disponibili:
//:    - la `struct` `Post`
//:    - i metodi: `showPost(_ post: Post)`, `choosePost() -> Int` e `appendPost(_ post: Post)`.
//:
//: - Note:
//:    1. Crea un post con un testo descrittivo, un'immagine, un luogo di pubblicazione, 2 tags e 1 hashtag
//:    2. Visualizza il post
//:    3. Crea la funzione `savePost(_ post: Post)`, che avrà il compito di salvare tutte le proprietà del post in myProfileManager (istanza di ProfileManager) e su un file JSON
//:    4. Esegui ancora una volta il Playground per verificare il salvataggio del post.
//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
print("** Service Console **\n\n")

/// Modello del Post
struct Post: Hashable, Codable {
    /// Testo del Post (Type: String)
    var description: String
    
    /// Numero di like del Post (Type: Int)
    var likeCounter = 0
    
    /// Numero di commenti del Post (Type: Int)
    var commentCounter: Int { comments.count }
    
    /// Immagine del Post (Type: Data?)
    var image: Data?
    
    /// Commenti del Post (Type: [String: String])
    var comments: [String: String] = [:]
    
    /// Tag del Post (Type: [String: Int])
    var displayTags: [String: Int] = [:]
    
    /// Tag del Post (Type: [String])
    var tags: [String] = []
    
    /// Hashtag del Post (Type: [String: Int])
    var displayHashtags: [String: Int] = [:]
    
    /// Hashtag del Post (Type: [String])
    var hashtags: [String] = []
    
    /// Numero di condivisioni del Post (Type: Int)
    var shareCounter = 0
    
    let date = Date()
    
    /// Data di pubblicazione del Post formattata (Type: String)
    var publicationDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium

        return formatter.string(from: date)
    }
    
    /// Luogo del Post (Type: String?)
    var publicationPlace: String?
    
    /// Array delle Proprietà utilizzate dal Post (Type: [Property])
    var properties: [Property] = []
    
    /// Incrementa il numero di like del Post
    mutating func like() {
        likeCounter += 1
    }
    
    /// Aggiunge un Commento al Post richiedendo un username e il testo del commento
    mutating func comment(_ username: String, text: String) {
        comments[username] = text
    }
    
    /// Incrementa il numero di condivisioni di un Post
    mutating func share() {
        shareCounter += 1
    }
    
    /// Proprietà di un Post
    enum Property: String, Codable {
        case description = "Testo ✍️"
        case image = "Foto 🖼"
        case tags = "Tags ＠"
        case hashtags = "Hashtags #️⃣"
        case publicationPlace = "Luogo 📍"
    }
    
    init(withDescription description: String) {
        self.description = description
        properties.append(.description)
    }
}

let demoURL = documentsDirectory.appendingPathComponent("demo_saved_posts").appendingPathExtension("json")

/// Mostra il contenuto del Post fornito in ingresso
func showPost(_ post: Post) {
    sleep(1)
    
    show("👤: \(myProfileManager.username)")
    
    show("📝: \(post.description)")
    
    if let pubPlace = post.publicationPlace {
        show("ℹ️: \(pubPlace) - \(post.publicationDate)")
    } else {
        show("📅: \(post.publicationDate)")
    }
    
    if let image = post.image { show(Image(data: image)!) }
    
    if !post.tags.isEmpty {
        let joinedTags = post.tags.joined(separator: " ")
        show(joinedTags)
    }
    
    if !post.hashtags.isEmpty {
        let joinedHashtags = post.hashtags.joined(separator: " ")
        show(joinedHashtags)
    }
    
    show("❤️\(post.likeCounter) – 💬\(post.commentCounter) – 📱\(post.shareCounter)")
}

/// Fornisce l'indice del Post selezionato nell'array posts
func choosePost() -> Int {
    var postsDisplayKeys: [String] = myProfileManager.postsDisplay.keys.map {
        $0
    }
    
    show("🧑‍💻 > Scegli un post 🔎")
    let postIndex = myProfileManager.postsDisplay[askForChoice(strings: postsDisplayKeys)] as! Int
    
    return postIndex
}

/// Salva un post in myProfileManager (istanza di ProfileManager)
func appendPost(_ post: Post) {
    myProfileManager.postsDisplay["\(post.description) - \(post.publicationDate)"] = myProfileManager.posts.isEmpty ? 0 : myProfileManager.posts.count - 1
    myProfileManager.posts.append(post)
}

final class ProfileManager: Codable {
    var posts: [Post]
    var postsDisplay: [String: Int]
    var username: String
    
    /// Salva un istanza della Classe ProfileManager in un file JSON
    func save() {
        do {
            let encoded = try JSONEncoder().encode(myProfileManager)
            print("Encoding succeded")
            do {
                try encoded.write(to: demoURL)
            } catch {
                print("Error writing to the given URL: \(error.localizedDescription)")
            }
            
        } catch {
            print("An error was thrown while encoding: \(error.localizedDescription)")
        }
    }
    
    init() {
        // Decodifica del file JSON per inizializzare la Classe
        if let data = try? Data(contentsOf: demoURL) {
            print(data)
            do {
                let decoded = try JSONDecoder().decode(ProfileManager.self, from: data)
                self.posts = decoded.posts
                self.postsDisplay = decoded.postsDisplay
                
                print("Data Loaded")
                print(decoded.posts)
                
                self.username = {
                    show("🧑‍💻 > Ciao!")
                    sleep(1)
                    show("🧑‍💻 > Sto caricando il tuo profilo")
                    sleep(1)
                    show("🧑‍💻 > ...")
                    sleep(2)
                    show("🧑‍💻 > Inserisci il tuo username")
                    let username = ask("username")
                    
                    return username
                }()
                
                return
            } catch {
                print("An error was thrown while decoding: \(error.localizedDescription)")
            }
        }
        print("No saved Data")
        self.posts = []
        self.postsDisplay = [:]
        self.username = {
            show("🧑‍💻 > Ciao!")
            sleep(1)
            show("🧑‍💻 > Sto caricando il tuo profilo")
            sleep(1)
            show("🧑‍💻 > ...")
            sleep(2)
            show("🧑‍💻 > Inserisci il tuo username")
            let username = ask("username")
            
            return username
        }()
    }
}

//#-end-hidden-code
let myProfileManager = ProfileManager()
//#-editable-code Tap to enter code
//#-end-editable-code
