//: # Prova anche Tu!
//: - Experiment:
//: Prova anche tu a realizzare una versione personalizzata del modello `Risposte`. Ecco alcuni suggerimenti proposti per livelli di difficoltà:
//:     - **base:** personalizza il tuo profilo, creando ad esempio un quiz tematico
//:     - **intermedio:** tieni traccia delle risposte fornite durante le esecuzioni del quiz
//:     - **avanzato:** crea una versione distribuita dell'applicativo `Social Media Manager`
//:
//: Puoi condividere le tue attività inviando una mail al nostro supporto: [playgrounds@sacrocuorenapoli.it](mailto:playgrounds@sacrocuorenapoli.it).
//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code

import Foundation
print("** Service Console **\n\n")

//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
